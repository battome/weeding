import coupleImage from "@/assets/couple-landscape.jpg";

const StorySection = () => {
  return (
    <section id="notre-histoire" className="wedding-section bg-background">
      <div className="wedding-container">
        <p className="font-accent text-lg tracking-[0.2em] uppercase text-accent-foreground/60 text-center mb-3">
          Notre Histoire
        </p>
        <h2 className="section-title">Bienvenue à bord de notre plus beau voyage</h2>
        <div className="wedding-divider" />

        <div className="grid md:grid-cols-2 gap-12 items-center mt-16">
          <div className="relative">
            <div className="absolute -inset-4 bg-accent/30 rounded-lg -rotate-2" />
            <img
              src={coupleImage}
              alt="Alexia et Alexandre"
              className="relative rounded-lg w-full h-[400px] object-cover shadow-lg"
            />
          </div>

          <div className="space-y-6 text-foreground/80 leading-relaxed">
            <p>
              Entre la lumière de la Méditerranée, les paysages de la Grèce et l'élégance 
              de la France, notre histoire s'écrit entre deux cultures qui nous sont chères. 
              Ce mariage est pour nous l'occasion de réunir ces deux univers et de célébrer 
              ce mélange qui fait aussi la richesse de notre couple.
            </p>
            <p>
              Nous avons imaginé cette journée comme un véritable voyage : un moment de 
              partage, de joie et de fête, entourés de nos familles et de nos amis venus 
              de près ou de loin.
            </p>
            <p>
              Athènes sera le point de départ de cette belle aventure, où traditions 
              grecques et esprit français se rencontreront pour créer des souvenirs 
              inoubliables.
            </p>
            <p className="font-accent text-xl italic text-primary">
              Merci de faire partie de ce voyage avec nous. Votre présence rendra cette 
              célébration encore plus spéciale.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default StorySection;
