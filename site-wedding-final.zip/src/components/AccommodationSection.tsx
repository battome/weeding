
import { Bed } from "lucide-react";

const AccommodationSection = () => {
  return (
    <section id="hebergements" className="wedding-section bg-secondary/30">
      <div className="wedding-container">

        <p className="font-accent text-lg tracking-[0.2em] uppercase text-accent-foreground/60 text-center mb-3">
          Séjour
        </p>
        <h2 className="section-title">Hôtels & Airbnb</h2>
        <div className="wedding-divider" />

        <div className="max-w-3xl mx-auto mt-16">
          <div className="card-wedding">
            <div className="flex items-start gap-4">

              <div className="w-12 h-12 rounded-full bg-accent/40 flex items-center justify-center flex-shrink-0">
                <Bed className="w-5 h-5 text-primary" />
              </div>

              <div className="text-muted-foreground leading-relaxed space-y-4">

                <p>
                Si vous souhaitez séjourner dans le centre d’Athènes, à proximité de la cérémonie religieuse, nous vous conseillons de choisir un hôtel dans les quartiers de Monastiraki, Plaka ou Syntagma.
                </p>

                <p>
                Si vous préférez être en bord de mer, mais donc plus éloignés du centre d’Athènes et du lieu du mariage, vous pouvez regarder du côté de Porto Rafti, Nea Makri, Vouliagmeni ou Glyfada.
                </p>

                <p>
                Si vous souhaitez être proches du lieu de la réception, vous pouvez séjourner à Koropi, Karellas, Profitis Ilias, Peania ou Spata.
                </p>

                <p>
                Pour un logement plus économique tout en restant sur la ligne de métro reliant l’aéroport, vous pouvez regarder les quartiers de Agia Paraskevi ou Doukissis Plakentias.
                </p>

                <p>
                N’hésitez pas à consulter
                <a href="https://www.booking.com" target="_blank" rel="noopener noreferrer" className="text-primary underline ml-1">Booking.com</a>
                {" "}ou{" "}
                <a href="https://www.airbnb.com" target="_blank" rel="noopener noreferrer" className="text-primary underline">Airbnb</a>.
                </p>

                <p className="font-medium text-foreground">
                Dans tous les cas, il faudra prévoir un moyen de transport (voiture de location ou taxi) pour vous rendre de la cérémonie religieuse au lieu de la réception.
                </p>

              </div>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};

export default AccommodationSection;
