
import { CarTaxiFront } from "lucide-react";
import transportImage from "@/assets/transport-athenes.jpg";

const TransportSection = () => {
  return (
    <section id="transport" className="wedding-section bg-card">
      <div className="wedding-container">

        <p className="font-accent text-lg tracking-[0.2em] uppercase text-accent-foreground/60 text-center mb-3">
          Transport
        </p>
        <h2 className="section-title">Taxi & Location de voiture</h2>
        <div className="wedding-divider" />

        <div className="grid md:grid-cols-2 gap-12 items-center mt-16">

          <div className="card-wedding">
            <div className="flex items-start gap-4">

              <div className="w-12 h-12 rounded-full bg-accent/40 flex items-center justify-center flex-shrink-0">
                <CarTaxiFront className="w-5 h-5 text-primary" />
              </div>

              <div className="text-muted-foreground leading-relaxed space-y-4">

                <p>
                <strong>Taxis :</strong> Uber ou FREENOW sont très utilisés à Athènes.
                </p>

                <p>
                <strong>Location de voiture :</strong> À l’aéroport d’Athènes, tous les loueurs sont ouverts 24h/24 (Europcar, Sixt, Hertz, Enterprise).
                </p>

                <p>
                Nous vous conseillons Europcar, généralement le plus avantageux.
                </p>

                <p>
                Vous pouvez louer un véhicule à plusieurs (amis, famille). Il existe des voitures 4, 5 ou 9 places.
                </p>

                <p>
                <a href="https://www.europcar.fr/" target="_blank" rel="noopener noreferrer" className="block text-primary underline">Europcar</a>
                <a href="https://www.sixt.fr/" target="_blank" rel="noopener noreferrer" className="block text-primary underline">Sixt</a>
                <a href="https://www.hertz.fr/" target="_blank" rel="noopener noreferrer" className="block text-primary underline">Hertz</a>
                </p>

              </div>
            </div>
          </div>

          <div className="relative">
            <div className="absolute -inset-4 bg-secondary/60 rounded-lg rotate-2" />
            <img
              src={transportImage}
              alt="Location voiture Grèce"
              className="relative rounded-lg w-full h-[500px] object-cover shadow-lg"
            />
          </div>

        </div>
      </div>
    </section>
  );
};

export default TransportSection;
