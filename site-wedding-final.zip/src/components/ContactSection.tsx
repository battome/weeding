import { Mail, Heart } from "lucide-react";

const ContactSection = () => {
  return (
    <section id="contact" className="wedding-section bg-card">
      <div className="wedding-container text-center">
        <p className="font-accent text-lg tracking-[0.2em] uppercase text-accent-foreground/60 mb-3">
          Une question ?
        </p>
        <h2 className="section-title">Nous Contacter</h2>
        <div className="wedding-divider" />

        <p className="text-muted-foreground max-w-xl mx-auto mb-10">
          N'hésitez pas à nous contacter pour toute question concernant le mariage, 
          les déplacements ou l'hébergement. Nous serons ravis de vous aider !
        </p>

        <a href="mailto:alexia.alexandre2027@gmail.com" className="btn-wedding-outline gap-2">
          <Mail className="w-5 h-5" />
          Nous écrire
        </a>
      </div>

      {/* Footer */}
      <div className="mt-20 pt-10 border-t border-border text-center">
        <p className="font-display text-2xl mb-2">Alexia & Alexandre</p>
        <p className="font-accent text-lg text-muted-foreground mb-4">17 Juillet 2027</p>
        <p className="text-sm text-muted-foreground/60 flex items-center justify-center gap-1">
          Fait avec <Heart className="w-3 h-3 text-terracotta" /> pour notre plus beau jour
        </p>
      </div>
    </section>
  );
};

export default ContactSection;
