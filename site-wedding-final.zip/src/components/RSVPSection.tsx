import { useState } from "react";
import { Heart, Send } from "lucide-react";

const RSVPSection = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    guests: "1",
    attending: "",
    message: "",
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <section id="rsvp" className="wedding-section bg-background">
      <div className="wedding-container">
        <p className="font-accent text-lg tracking-[0.2em] uppercase text-accent-foreground/60 text-center mb-3">
          Répondez
        </p>
        <h2 className="section-title">Confirmer sa Présence</h2>
        <div className="wedding-divider" />

        <p className="text-center text-muted-foreground max-w-2xl mx-auto mb-12">
          Merci de nous confirmer votre présence avant le 17 mai 2027 afin que nous 
          puissions organiser au mieux cette journée.
        </p>

        {submitted ? (
          <div className="max-w-lg mx-auto text-center card-wedding">
            <Heart className="w-12 h-12 text-terracotta mx-auto mb-4" />
            <h3 className="font-display text-2xl mb-3">Merci !</h3>
            <p className="text-muted-foreground">
              Votre réponse a bien été enregistrée. Nous avons hâte de vous retrouver à Athènes !
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="max-w-lg mx-auto space-y-6">
            <div>
              <label className="block font-accent text-lg mb-2">Nom complet</label>
              <input
                type="text"
                required
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full px-4 py-3 bg-card border border-border rounded-sm font-body
                           focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary
                           transition-colors"
                placeholder="Votre nom"
              />
            </div>

            <div>
              <label className="block font-accent text-lg mb-2">Email</label>
              <input
                type="email"
                required
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="w-full px-4 py-3 bg-card border border-border rounded-sm font-body
                           focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary
                           transition-colors"
                placeholder="votre@email.com"
              />
            </div>

            <div>
              <label className="block font-accent text-lg mb-2">Nombre de personnes</label>
              <select
                value={formData.guests}
                onChange={(e) => setFormData({ ...formData, guests: e.target.value })}
                className="w-full px-4 py-3 bg-card border border-border rounded-sm font-body
                           focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary
                           transition-colors"
              >
                {[1, 2, 3, 4, 5].map((n) => (
                  <option key={n} value={n}>
                    {n} {n === 1 ? "personne" : "personnes"}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-accent text-lg mb-3">Serez-vous présent(e) ?</label>
              <div className="flex gap-4">
                {["Oui, avec joie !", "Malheureusement non"].map((option) => (
                  <label
                    key={option}
                    className={`flex-1 text-center px-4 py-3 border rounded-sm cursor-pointer transition-all
                      ${formData.attending === option
                        ? "bg-primary text-primary-foreground border-primary"
                        : "bg-card border-border hover:border-primary/50"
                      }`}
                  >
                    <input
                      type="radio"
                      name="attending"
                      value={option}
                      required
                      onChange={(e) => setFormData({ ...formData, attending: e.target.value })}
                      className="sr-only"
                    />
                    <span className="font-accent text-lg">{option}</span>
                  </label>
                ))}
              </div>
            </div>

            <div>
              <label className="block font-accent text-lg mb-2">Un petit mot ? (optionnel)</label>
              <textarea
                value={formData.message}
                onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                rows={3}
                className="w-full px-4 py-3 bg-card border border-border rounded-sm font-body
                           focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary
                           transition-colors resize-none"
                placeholder="Votre message pour les mariés..."
              />
            </div>

            <button type="submit" className="btn-wedding w-full gap-2">
              <Send className="w-4 h-4" />
              Envoyer ma réponse
            </button>
          </form>
        )}
      </div>
    </section>
  );
};

export default RSVPSection;
